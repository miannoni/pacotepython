# pacotepython
Esse projeto é parte da eletiva de desenvolvimento aberto do Insper (https://github.com/Insper/dev-aberto) e é uma demonstração do conhecimento de como criar um pacote python instalavel atraves do comando 'pip install'
